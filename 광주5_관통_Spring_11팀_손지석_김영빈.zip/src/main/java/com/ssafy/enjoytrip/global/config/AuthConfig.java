package com.ssafy.enjoytrip.global.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AuthConfig {

}
